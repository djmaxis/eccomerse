﻿namespace Ecommerce.BLL.DTOs;

public class RegisterDto
{
    public string Nombre { get; set; } = null!;
    public string Correo { get; set; } = null!;
    public string Contrasena { get; set; } = null!;
}
